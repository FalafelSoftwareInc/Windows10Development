﻿using Win10MvvmLight.Portable.Model;

namespace Win10MvvmLight.Portable.ViewModels
{
	public class SecondPageViewModel : BaseViewModel
	{
		private TestItem selectedItem;

		public TestItem SelectedItem
		{
			get { return selectedItem; }
			set
			{
				selectedItem = value;
				RaisePropertyChanged();
			}
		}
	}
}
﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Win10MvvmLight.Portable.Model;

namespace Win10MvvmLight.Portable.ViewModels
{
	public class MainPageViewModel : BaseViewModel
	{
		private ObservableCollection<TestItem> testItems = new ObservableCollection<TestItem>();
		public ObservableCollection<TestItem> TestItems
		{
			get { return testItems; }
			set
			{
				testItems = value;
				RaisePropertyChanged();
			}
		}
	}
}
